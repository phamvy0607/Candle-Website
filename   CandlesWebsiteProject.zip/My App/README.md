cd ProJect-Vy
### `npm i`
### `npm run dev`

cd frontend
### `npm i`
### `npm start`